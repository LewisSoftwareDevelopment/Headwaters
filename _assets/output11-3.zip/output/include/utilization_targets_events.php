<?php 
class eventclass_utilization_targets  extends eventsBase
{ 
	function eventclass_utilization_targets()
	{
	// fill list of events
		$this->events["BeforeProcessList"]=true;


//	onscreen events


	}
// Captchas functions	

//	handlers

				// List page: Before process
function BeforeProcessList(&$conn,&$pageObject)
{

		
;		
} // function BeforeProcessList

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//	onscreen events

} 
?>
