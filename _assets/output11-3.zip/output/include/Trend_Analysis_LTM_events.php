<?php 
class eventclass_Trend_Analysis_LTM  extends eventsBase
{ 
	function eventclass_Trend_Analysis_LTM()
	{
	// fill list of events
		$this->events["BeforeProcessReport"]=true;


//	onscreen events


	}
// Captchas functions	

//	handlers

		
		
		
		
		
		
		
		
				// Report page: Before process
function BeforeProcessReport(&$conn,&$pageObject)
{

		
// Place event code here.
// Use "Add Action" button to add code snippets.
;		
} // function BeforeProcessReport

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//	onscreen events

} 
?>
