<?php 
class eventclass_nda_per_month  extends eventsBase
{ 
	function eventclass_nda_per_month()
	{
	// fill list of events
		$this->events["BeforeProcessList"]=true;


//	onscreen events


	}
// Captchas functions	

//	handlers

				// List page: Before process
function BeforeProcessList(&$conn,&$pageObject)
{

		





// Place event code here.
// Use "Add Action" button to add code snippets.
;		
} // function BeforeProcessList

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//	onscreen events

} 
?>
