<?php
$dalTablereferral_company = array();
$dalTablereferral_company["ID"] = array("type"=>3,"varname"=>"ID");
$dalTablereferral_company["Name"] = array("type"=>200,"varname"=>"Name");
	$dalTablereferral_company["ID"]["key"]=true;
$dal_info["referral company"]=&$dalTablereferral_company;

?>