<?php
$dalTableme_close = array();
$dalTableme_close["ID"] = array("type"=>3,"varname"=>"ID");
$dalTableme_close["CClient"] = array("type"=>200,"varname"=>"CClient");
$dalTableme_close["CDealtype"] = array("type"=>200,"varname"=>"CDealtype");
$dalTableme_close["CAmount"] = array("type"=>3,"varname"=>"CAmount");
$dalTableme_close["CSlot"] = array("type"=>200,"varname"=>"CSlot");
	$dalTableme_close["ID"]["key"]=true;
$dal_info["me-close"]=&$dalTableme_close;

?>