<?php
$dalTablereferral_individual = array();
$dalTablereferral_individual["ID"] = array("type"=>3,"varname"=>"ID");
$dalTablereferral_individual["Name"] = array("type"=>200,"varname"=>"Name");
$dalTablereferral_individual["Last Name"] = array("type"=>200,"varname"=>"Last_Name");
$dalTablereferral_individual["First Name"] = array("type"=>200,"varname"=>"First_Name");
	$dalTablereferral_individual["ID"]["key"]=true;
$dal_info["referral individual"]=&$dalTablereferral_individual;

?>