<?php
$dalTablebpengagmentstotal = array();
$dalTablebpengagmentstotal["ID"] = array("type"=>3,"varname"=>"ID");
$dalTablebpengagmentstotal["Banker"] = array("type"=>200,"varname"=>"Banker");
$dalTablebpengagmentstotal["Engagements"] = array("type"=>200,"varname"=>"Engagements");
$dalTablebpengagmentstotal["Wheelhouse"] = array("type"=>3,"varname"=>"Wheelhouse");
$dalTablebpengagmentstotal["Speculative"] = array("type"=>3,"varname"=>"Speculative");
$dalTablebpengagmentstotal["Minimum"] = array("type"=>3,"varname"=>"Minimum");
$dalTablebpengagmentstotal["rows"] = array("type"=>3,"varname"=>"rows");
	$dalTablebpengagmentstotal["ID"]["key"]=true;
$dal_info["bpengagmentstotal"]=&$dalTablebpengagmentstotal;

?>