<?php
$dalTablebprevstore = array();
$dalTablebprevstore["ID"] = array("type"=>3,"varname"=>"ID");
$dalTablebprevstore["Name"] = array("type"=>200,"varname"=>"Name");
$dalTablebprevstore["y1"] = array("type"=>3,"varname"=>"y1");
$dalTablebprevstore["y2"] = array("type"=>3,"varname"=>"y2");
$dalTablebprevstore["y3"] = array("type"=>3,"varname"=>"y3");
	$dalTablebprevstore["ID"]["key"]=true;
$dal_info["bprevstore"]=&$dalTablebprevstore;

?>