<?php
$dalTableme_el = array();
$dalTableme_el["ID"] = array("type"=>3,"varname"=>"ID");
$dalTableme_el["ELClient"] = array("type"=>200,"varname"=>"ELClient");
$dalTableme_el["ELDealType"] = array("type"=>200,"varname"=>"ELDealType");
$dalTableme_el["ELAmount"] = array("type"=>3,"varname"=>"ELAmount");
$dalTableme_el["ELSlot"] = array("type"=>200,"varname"=>"ELSlot");
	$dalTableme_el["ID"]["key"]=true;
$dal_info["me-el"]=&$dalTableme_el;

?>