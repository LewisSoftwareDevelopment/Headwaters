<?php
$dalTablessvsop = array();
$dalTablessvsop["ID"] = array("type"=>3,"varname"=>"ID");
$dalTablessvsop["SS"] = array("type"=>200,"varname"=>"SS");
$dalTablessvsop["Month"] = array("type"=>200,"varname"=>"Month");
$dalTablessvsop["Year"] = array("type"=>7,"varname"=>"Year");
	$dalTablessvsop["ID"]["key"]=true;
$dal_info["ssvsop"]=&$dalTablessvsop;

?>