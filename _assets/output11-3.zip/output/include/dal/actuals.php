<?php
$dalTableactuals = array();
$dalTableactuals["ID"] = array("type"=>3,"varname"=>"ID");
$dalTableactuals["YTD Net Actual"] = array("type"=>3,"varname"=>"YTD_Net_Actual");
$dalTableactuals["This Year Buget Gross"] = array("type"=>3,"varname"=>"This_Year_Buget_Gross");
$dalTableactuals["This Year Budget Net"] = array("type"=>3,"varname"=>"This_Year_Budget_Net");
$dalTableactuals["YTDgrossact"] = array("type"=>3,"varname"=>"YTDgrossact");
	$dalTableactuals["ID"]["key"]=true;
$dal_info["actuals"]=&$dalTableactuals;

?>