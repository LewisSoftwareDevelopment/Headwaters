<?php
$dalTablefee_split = array();
$dalTablefee_split["ID"] = array("type"=>3,"varname"=>"ID");
$dalTablefee_split["Name"] = array("type"=>200,"varname"=>"Name");
	$dalTablefee_split["ID"]["key"]=true;
$dal_info["fee split"]=&$dalTablefee_split;

?>