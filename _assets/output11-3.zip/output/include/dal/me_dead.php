<?php
$dalTableme_dead = array();
$dalTableme_dead["ID"] = array("type"=>3,"varname"=>"ID");
$dalTableme_dead["DClient"] = array("type"=>200,"varname"=>"DClient");
$dalTableme_dead["DDealtype"] = array("type"=>200,"varname"=>"DDealtype");
$dalTableme_dead["DAmount"] = array("type"=>3,"varname"=>"DAmount");
$dalTableme_dead["DSlot"] = array("type"=>200,"varname"=>"DSlot");
	$dalTableme_dead["ID"]["key"]=true;
$dal_info["me-dead"]=&$dalTableme_dead;

?>