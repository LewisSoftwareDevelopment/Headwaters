<?php
$dalTableme_totals = array();
$dalTableme_totals["ID"] = array("type"=>3,"varname"=>"ID");
$dalTableme_totals["CClient"] = array("type"=>200,"varname"=>"CClient");
$dalTableme_totals["CDealtype"] = array("type"=>200,"varname"=>"CDealtype");
$dalTableme_totals["CAmount"] = array("type"=>3,"varname"=>"CAmount");
$dalTableme_totals["CSlot"] = array("type"=>200,"varname"=>"CSlot");
$dalTableme_totals["DClient"] = array("type"=>200,"varname"=>"DClient");
$dalTableme_totals["DDealtype"] = array("type"=>200,"varname"=>"DDealtype");
$dalTableme_totals["DAmount"] = array("type"=>3,"varname"=>"DAmount");
$dalTableme_totals["DSlot"] = array("type"=>200,"varname"=>"DSlot");
$dalTableme_totals["ELClient"] = array("type"=>200,"varname"=>"ELClient");
$dalTableme_totals["ELDealtype"] = array("type"=>200,"varname"=>"ELDealtype");
$dalTableme_totals["ELAmount"] = array("type"=>3,"varname"=>"ELAmount");
$dalTableme_totals["ELSlot"] = array("type"=>200,"varname"=>"ELSlot");
	$dalTableme_totals["ID"]["key"]=true;
$dal_info["me-totals"]=&$dalTableme_totals;

?>