<?php
$dalTablebankerrev = array();
$dalTablebankerrev["ID"] = array("type"=>3,"varname"=>"ID");
$dalTablebankerrev["Year"] = array("type"=>200,"varname"=>"Year");
$dalTablebankerrev["Revenue total"] = array("type"=>14,"varname"=>"Revenue_total");
$dalTablebankerrev["Name"] = array("type"=>200,"varname"=>"Name");
	$dalTablebankerrev["ID"]["key"]=true;
$dal_info["bankerrev"]=&$dalTablebankerrev;

?>