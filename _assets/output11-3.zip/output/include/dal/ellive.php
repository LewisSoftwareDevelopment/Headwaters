<?php
$dalTableellive = array();
$dalTableellive["ID"] = array("type"=>3,"varname"=>"ID");
$dalTableellive["Jan"] = array("type"=>200,"varname"=>"Jan");
$dalTableellive["Feb"] = array("type"=>200,"varname"=>"Feb");
$dalTableellive["Mar"] = array("type"=>200,"varname"=>"Mar");
$dalTableellive["April"] = array("type"=>200,"varname"=>"April");
$dalTableellive["May"] = array("type"=>200,"varname"=>"May");
$dalTableellive["June"] = array("type"=>200,"varname"=>"June");
$dalTableellive["July"] = array("type"=>200,"varname"=>"July");
$dalTableellive["Aug"] = array("type"=>200,"varname"=>"Aug");
$dalTableellive["Sep"] = array("type"=>200,"varname"=>"Sep");
$dalTableellive["Oct"] = array("type"=>200,"varname"=>"Oct");
$dalTableellive["Nov"] = array("type"=>200,"varname"=>"Nov");
$dalTableellive["Dec"] = array("type"=>200,"varname"=>"Dec");
	$dalTableellive["ID"]["key"]=true;
$dal_info["ellive"]=&$dalTableellive;

?>