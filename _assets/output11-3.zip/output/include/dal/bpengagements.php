<?php
$dalTablebpengagements = array();
$dalTablebpengagements["ID"] = array("type"=>3,"varname"=>"ID");
$dalTablebpengagements["rows"] = array("type"=>3,"varname"=>"rows");
$dalTablebpengagements["Banker"] = array("type"=>200,"varname"=>"Banker");
$dalTablebpengagements["Engagements"] = array("type"=>200,"varname"=>"Engagements");
$dalTablebpengagements["IBC"] = array("type"=>3,"varname"=>"IBC");
$dalTablebpengagements["Closed"] = array("type"=>3,"varname"=>"Closed");
	$dalTablebpengagements["ID"]["key"]=true;
$dal_info["bpengagements"]=&$dalTablebpengagements;

?>