<?php
$dalTablenda_per_month = array();
$dalTablenda_per_month["ID"] = array("type"=>3,"varname"=>"ID");
$dalTablenda_per_month["Date"] = array("type"=>7,"varname"=>"Date");
$dalTablenda_per_month["Total per Month"] = array("type"=>3,"varname"=>"Total_per_Month");
	$dalTablenda_per_month["ID"]["key"]=true;
$dal_info["nda per month"]=&$dalTablenda_per_month;

?>