<?php
$dalTableinmarketloi = array();
$dalTableinmarketloi["ID"] = array("type"=>3,"varname"=>"ID");
$dalTableinmarketloi["Jan"] = array("type"=>200,"varname"=>"Jan");
$dalTableinmarketloi["Feb"] = array("type"=>200,"varname"=>"Feb");
$dalTableinmarketloi["Mar"] = array("type"=>200,"varname"=>"Mar");
$dalTableinmarketloi["April"] = array("type"=>200,"varname"=>"April");
$dalTableinmarketloi["May"] = array("type"=>200,"varname"=>"May");
$dalTableinmarketloi["June"] = array("type"=>200,"varname"=>"June");
$dalTableinmarketloi["July"] = array("type"=>200,"varname"=>"July");
$dalTableinmarketloi["Aug"] = array("type"=>200,"varname"=>"Aug");
$dalTableinmarketloi["Sep"] = array("type"=>200,"varname"=>"Sep");
$dalTableinmarketloi["Oct"] = array("type"=>200,"varname"=>"Oct");
$dalTableinmarketloi["Nov"] = array("type"=>200,"varname"=>"Nov");
$dalTableinmarketloi["Dec"] = array("type"=>200,"varname"=>"Dec");
	$dalTableinmarketloi["ID"]["key"]=true;
$dal_info["inmarketloi"]=&$dalTableinmarketloi;

?>