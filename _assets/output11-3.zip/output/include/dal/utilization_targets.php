<?php
$dalTableutilization_targets = array();
$dalTableutilization_targets["ID"] = array("type"=>3,"varname"=>"ID");
$dalTableutilization_targets["IBC per MD"] = array("type"=>3,"varname"=>"IBC_per_MD");
$dalTableutilization_targets["IBC Total MD"] = array("type"=>3,"varname"=>"IBC_Total_MD");
$dalTableutilization_targets["IBC YTD Target"] = array("type"=>3,"varname"=>"IBC_YTD_Target");
$dalTableutilization_targets["EL per MD"] = array("type"=>3,"varname"=>"EL_per_MD");
$dalTableutilization_targets["EL Total MD"] = array("type"=>3,"varname"=>"EL_Total_MD");
$dalTableutilization_targets["EL YTD Target"] = array("type"=>3,"varname"=>"EL_YTD_Target");
$dalTableutilization_targets["Closing per MD"] = array("type"=>3,"varname"=>"Closing_per_MD");
$dalTableutilization_targets["Closing Total MD"] = array("type"=>3,"varname"=>"Closing_Total_MD");
$dalTableutilization_targets["Closing YTD MD"] = array("type"=>3,"varname"=>"Closing_YTD_MD");
	$dalTableutilization_targets["ID"]["key"]=true;
$dal_info["utilization targets"]=&$dalTableutilization_targets;

?>