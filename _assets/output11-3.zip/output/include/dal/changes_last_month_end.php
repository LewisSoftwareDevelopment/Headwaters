<?php
$dalTablechanges_last_month_end = array();
$dalTablechanges_last_month_end["ID"] = array("type"=>3,"varname"=>"ID");
$dalTablechanges_last_month_end["LMLive"] = array("type"=>3,"varname"=>"LMLive");
$dalTablechanges_last_month_end["Closed"] = array("type"=>3,"varname"=>"Closed");
$dalTablechanges_last_month_end["Dead"] = array("type"=>3,"varname"=>"Dead");
$dalTablechanges_last_month_end["NewEl"] = array("type"=>3,"varname"=>"NewEl");
$dalTablechanges_last_month_end["CurrentLive"] = array("type"=>3,"varname"=>"CurrentLive");
$dalTablechanges_last_month_end["CClient"] = array("type"=>200,"varname"=>"CClient");
$dalTablechanges_last_month_end["CDealtype"] = array("type"=>200,"varname"=>"CDealtype");
$dalTablechanges_last_month_end["CAmount"] = array("type"=>3,"varname"=>"CAmount");
$dalTablechanges_last_month_end["CSlot"] = array("type"=>200,"varname"=>"CSlot");
$dalTablechanges_last_month_end["DClient"] = array("type"=>200,"varname"=>"DClient");
$dalTablechanges_last_month_end["DDealtype"] = array("type"=>200,"varname"=>"DDealtype");
$dalTablechanges_last_month_end["DAmount"] = array("type"=>3,"varname"=>"DAmount");
$dalTablechanges_last_month_end["DSlot"] = array("type"=>200,"varname"=>"DSlot");
$dalTablechanges_last_month_end["ELClinet"] = array("type"=>200,"varname"=>"ELClinet");
$dalTablechanges_last_month_end["ELDealType"] = array("type"=>200,"varname"=>"ELDealType");
$dalTablechanges_last_month_end["ELAmount"] = array("type"=>3,"varname"=>"ELAmount");
$dalTablechanges_last_month_end["ELSlot"] = array("type"=>200,"varname"=>"ELSlot");
	$dalTablechanges_last_month_end["ID"]["key"]=true;
$dal_info["changes last month end"]=&$dalTablechanges_last_month_end;

?>