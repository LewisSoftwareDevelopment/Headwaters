<?php
$dalTablebankerrank = array();
$dalTablebankerrank["ID"] = array("type"=>3,"varname"=>"ID");
$dalTablebankerrank["Year"] = array("type"=>3,"varname"=>"Year");
$dalTablebankerrank["Name"] = array("type"=>200,"varname"=>"Name");
$dalTablebankerrank["Rank"] = array("type"=>3,"varname"=>"Rank");
	$dalTablebankerrank["ID"]["key"]=true;
$dal_info["bankerrank"]=&$dalTablebankerrank;

?>